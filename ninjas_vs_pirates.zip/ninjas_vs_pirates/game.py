from classes.ninja import Ninja
from classes.pirate import Pirate

naruto = Ninja("Naruto")

jack_sparrow = Pirate("Jack Sparrow")

naruto.show_stats()
jack_sparrow.show_stats()
print("=============================")
jack_sparrow.spar(naruto).spar(naruto).spar(naruto).spar(naruto).spar(naruto).spar(naruto).spar(naruto).spar(naruto)
naruto.shuriken(jack_sparrow).shuriken(jack_sparrow).shuriken(jack_sparrow).shuriken(jack_sparrow).shuriken(jack_sparrow).shuriken(jack_sparrow)
naruto.show_stats()
jack_sparrow.show_stats()